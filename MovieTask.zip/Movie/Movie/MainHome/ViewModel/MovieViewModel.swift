//
//  MovieViewModel.swift
//  Movie
//
//  Created by patururamesh on 27/08/24.
//


import Foundation


class MovieViewModel: ObservableObject {

    @Published var movie: [Movie]? // Corrected variable name to 'movies' for clarity
    @Published var errorMessage: String?
    @Published var searchData: [Movie] = [] // Fixed the syntax error and initialized it

    private let service: MovieAPI

    init(service: MovieAPI = MovieAPI()) {
        self.service = service
    }

    func getMovieDetails(callback: @escaping () -> Void) {
        service.fetchMovieDetails(urlString: "https://www.omdbapi.com/?apikey=64e5c48a&type=movie&s=Don") { [weak self] (result: Result<MovieSearch, APIError>) in
            DispatchQueue.main.async {
                switch result {
                case .success(let movieInfo):
                    self?.movie = movieInfo.search
                    self?.searchData = self?.movie ?? []
                    callback()
                case .failure(let error):
                    self?.errorMessage = error.localizedDescription
                    callback()
                }
            }
        }
    }
}
