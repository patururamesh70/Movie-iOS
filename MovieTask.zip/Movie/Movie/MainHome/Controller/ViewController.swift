//
//  ViewController.swift
//  Movie
//
//  Created by patururamesh on 27/08/24.
//

import UIKit

class ViewController: LoadViewController {

    @IBOutlet weak var movieTableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!

    var movieViewModel = MovieViewModel()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.activityIndicatorBegin()

        movieViewModel.getMovieDetails { [weak self] in
            self?.activityIndicatorEnd()
            self?.movieTableView.reloadData()
        }

        searchBar.delegate = self
        movieTableView.dataSource = self
        movieTableView.delegate = self
    }

    @IBAction func favouriteMovie(_ sender: Any) {
        if let movieData = UserDefaults.standard.data(forKey: "movie") {
            let decoder = JSONDecoder()
            if let decodedPerson = try? decoder.decode(MovieData.self, from: movieData) {
                showFavMoviesAlert(message: "Your favourite movie is \(decodedPerson.name) and was released in \(decodedPerson.year)")
            }
        }
    }

    func showFavMoviesAlert(message: String) {
        let alert = UIAlertController(title: "Favourite Movies", message: message, preferredStyle: .alert)
        let dismiss = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alert.addAction(dismiss)
        present(alert, animated: true, completion: nil)
    }

    @objc func favourite(sender: UIButton) {
        let movie = movieViewModel.searchData[sender.tag]
        let favData = MovieData(name: movie.title, year: movie.year)
        do {
            let encoder = JSONEncoder()
            if let encoded = try? encoder.encode(favData) {
                UserDefaults.standard.set(encoded, forKey: "movie")
                showFavMoviesAlert(message: "Successfully Saved")
            }
        }
    }
}

extension ViewController: UISearchBarDelegate {

    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if !searchText.isEmpty {
            movieViewModel.searchData = movieViewModel.movie?.filter {
                (item: Movie) -> Bool in
                return item.title.range(of: searchText, options: .caseInsensitive, range: nil, locale: nil) != nil
            } ?? [Movie]()
        } else {
            movieViewModel.searchData = movieViewModel.movie ?? [Movie]()
        }
        movieTableView.reloadData()
    }
}

extension ViewController: UITableViewDataSource, UITableViewDelegate {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return movieViewModel.searchData.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let movieCell = tableView.dequeueReusableCell(withIdentifier: "MovieCell", for: indexPath) as? MovieCell else {
            return UITableViewCell()
        }
        movieCell.favBtn.tag = indexPath.row
        movieCell.favBtn.addTarget(self, action: #selector(favourite(sender:)), for: .touchUpInside)
        movieCell.setupMovieInformation(movie: movieViewModel.searchData[indexPath.row])
        return movieCell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let detailsVc = self.storyboard?.instantiateViewController(withIdentifier: "MovieDetailsScreenViewController") as? MovieDetailsScreenViewController else {
            return
        }
        let viewModel = MovieDetailsViewModel()
        viewModel.movie = movieViewModel.searchData[indexPath.row]
        detailsVc.viewModel = viewModel
        self.navigationController?.pushViewController(detailsVc, animated: true)
    }
}
