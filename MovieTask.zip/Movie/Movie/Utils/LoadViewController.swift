//
//  BaseViewController.swift
//  Movie
//
// Created by patururamesh on 28/08/24.
//

import Foundation
import UIKit
class LoadViewController: UIViewController{
    var activityIndicator: UIActivityIndicatorView = UIActivityIndicatorView()
    var greyView: UIView = UIView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    func activityIndicatorBegin() {
        activityIndicator = UIActivityIndicatorView(frame: CGRectMake(0,0,50,50))
        activityIndicator.center = self.view.center
        activityIndicator.hidesWhenStopped = true
        activityIndicator.style = .large
        view.addSubview(activityIndicator)
        activityIndicator.startAnimating()
        greyView.frame = CGRectMake(0, 0, self.view.bounds.width, self.view.bounds.height)
        greyView.backgroundColor = .gray
        greyView.alpha = 0.5
        self.view.addSubview(greyView)
    }
        func activityIndicatorEnd() {
            self.activityIndicator.stopAnimating()
            self.greyView.removeFromSuperview()
    }
}






