//
//  MovieFavData.swift
//  Movie
//
//  Created by patururamesh on 28/08/24.
//

import Foundation

struct MovieData: Codable{
    let name: String
    let year : String

}
