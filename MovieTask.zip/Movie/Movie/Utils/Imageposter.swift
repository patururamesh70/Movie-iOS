//
//  ImageLoader.swift
//  Movie
//
//  Created by patururamesh on 28/08/24.
//

import Foundation
import UIKit
class Imageposter {
    var cache = NSCache<AnyObject, AnyObject>()
    class var sharedInstance: Imageposter  {
        struct Static {
            static let instance: Imageposter  = Imageposter ()
        }
        return Static.instance
        
    }
    
    func imageForUrl(urlString: String, completionHandler:@escaping (_ image: UIImage?, _ url: String) ->()) {
        let data: NSData? = self.cache.object(forKey: urlString as AnyObject) as? NSData
        if let imageData = data {
            let image = UIImage(data: imageData as Data)
            DispatchQueue.main.async {
                completionHandler(image, urlString)
            }
            return
        }
        
        let Task: URLSessionDataTask = URLSession.shared.dataTask(with: URL.init(string: urlString)!) { (data, response, error) in
            if error == nil {
                if data != nil {
                    let image = UIImage.init(data: data!)
                    self.cache.setObject(data! as AnyObject, forKey: urlString as AnyObject)
                    DispatchQueue.main.async {
                        completionHandler(image, urlString)
                    }
                }
            } else {
                completionHandler(nil, urlString)
            }
        }
        Task.resume()
    }
}
